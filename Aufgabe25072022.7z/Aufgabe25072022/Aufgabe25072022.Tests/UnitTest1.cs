﻿using Aufgabe25072022;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using System;

namespace Aufgabe25072022.Tests
{
	[TestClass]
	public class ProgramTests
	{
		[TestMethod]
		public void TestMethod1()
		{
			//arrange


			//act
			


			//assert


		}

		
	}
}
